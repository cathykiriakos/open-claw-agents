#!/usr/bin/env bash
# =============================================================================
# OpenClaw Setup Script — Mac Studio M4 Max (macOS Sequoia+)
# =============================================================================
# Run with: chmod +x setup_openclaw.sh && ./setup_openclaw.sh
# All operations are idempotent — safe to re-run.

set -euo pipefail

BLUE='\033[0;34m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
step() { echo -e "\n${BLUE}▶ $1${NC}"; }
ok()   { echo -e "${GREEN}✓ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }
fail() { echo -e "${RED}✗ $1${NC}"; exit 1; }

OPENCLAW_DIR="$HOME/.openclaw"
LOG_DIR="$OPENCLAW_DIR/logs"
MEMORY_DIR="$OPENCLAW_DIR/memory"
VECTORDB_DIR="$OPENCLAW_DIR/vectordb"
MODELS_DIR="$HOME/.ollama/models"      # Default; symlink to external NVMe if needed
PYTHON_VERSION="3.12.7"
NODE_VERSION="20"

# ─── 1. Homebrew ──────────────────────────────────────────────────────────────
step "Checking Homebrew"
if ! command -v brew &>/dev/null; then
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  # Add brew to PATH for Apple Silicon
  echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
  eval "$(/opt/homebrew/bin/brew shellenv)"
fi
brew update --quiet
ok "Homebrew ready"

# ─── 2. Ollama ────────────────────────────────────────────────────────────────
step "Installing Ollama"
if ! command -v ollama &>/dev/null; then
  brew install ollama
fi
ok "Ollama $(ollama --version 2>/dev/null | head -1)"

# Tune Ollama environment for M4 Max
# OLLAMA_MAX_LOADED_MODELS=2 prevents accidental OOM when two agents call simultaneously
OLLAMA_ENV_FILE="$HOME/.zshrc"
grep -q "OLLAMA_HOST" "$OLLAMA_ENV_FILE" 2>/dev/null || cat >> "$OLLAMA_ENV_FILE" <<'EOF'

# ── OpenClaw: Ollama tuning ──
export OLLAMA_HOST="127.0.0.1:11434"
export OLLAMA_MAX_LOADED_MODELS=2
export OLLAMA_NUM_PARALLEL=1
export OLLAMA_KEEP_ALIVE=10m
EOF
ok "Ollama environment tuned"

# ─── 3. Ollama launchd (Always-On) ────────────────────────────────────────────
step "Registering Ollama as launchd service"
PLIST_PATH="$HOME/Library/LaunchAgents/com.openclaw.ollama.plist"
mkdir -p "$HOME/Library/LaunchAgents"

cat > "$PLIST_PATH" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.openclaw.ollama</string>
  <key>ProgramArguments</key>
  <array>
    <string>/opt/homebrew/bin/ollama</string>
    <string>serve</string>
  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>OLLAMA_HOST</key>
    <string>127.0.0.1:11434</string>
    <key>OLLAMA_MAX_LOADED_MODELS</key>
    <string>2</string>
    <key>OLLAMA_NUM_PARALLEL</key>
    <string>1</string>
    <key>OLLAMA_KEEP_ALIVE</key>
    <string>10m</string>
    <key>HOME</key>
    <string>$HOME</string>
  </dict>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$LOG_DIR/ollama.log</string>
  <key>StandardErrorPath</key>
  <string>$LOG_DIR/ollama.err</string>
  <key>ThrottleInterval</key>
  <integer>10</integer>
</dict>
</plist>
EOF

# Load (or reload) the service
# Note: launchctl load is deprecated on macOS Ventura+. Use bootstrap/bootout.
launchctl bootout "gui/$(id -u)" "$PLIST_PATH" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST_PATH"
ok "Ollama launchd service active"

# ─── 4. Python via pyenv ──────────────────────────────────────────────────────
step "Setting up Python $PYTHON_VERSION via pyenv"
if ! command -v pyenv &>/dev/null; then
  brew install pyenv
  echo 'export PYENV_ROOT="$HOME/.pyenv"' >> "$HOME/.zshrc"
  echo 'export PATH="$PYENV_ROOT/bin:$PATH"'>> "$HOME/.zshrc"
  echo 'eval "$(pyenv init -)"' >> "$HOME/.zshrc"
  eval "$(pyenv init -)"
fi

pyenv install --skip-existing "$PYTHON_VERSION"
pyenv global "$PYTHON_VERSION"
ok "Python $(python --version)"

# ─── 5. Python virtual environment ────────────────────────────────────────────
step "Creating OpenClaw Python venv"
VENV_DIR="$OPENCLAW_DIR/venv"
if [ ! -d "$VENV_DIR" ]; then
  python -m venv "$VENV_DIR"
fi
# shellcheck disable=SC1090
source "$VENV_DIR/bin/activate"

pip install --quiet --upgrade pip
pip install --quiet \
  ollama \
  chromadb \
  mem0ai \
  httpx \
  pydantic \
  typer \
  rich \
  schedule \
  langchain \
  langchain-community \
  langchain-ollama \
  python-dotenv \
  arxiv \
  pypdf \
  beautifulsoup4 \
  playwright

# Install Playwright browsers (headless Chromium for Work-Life Agent)
python -m playwright install chromium

ok "Python dependencies installed"

# ─── 6. Node.js via nvm ───────────────────────────────────────────────────────
step "Setting up Node.js $NODE_VERSION"
if ! command -v nvm &>/dev/null; then
  brew install nvm
  mkdir -p "$HOME/.nvm"
  echo 'export NVM_DIR="$HOME/.nvm"' >> "$HOME/.zshrc"
  echo '[ -s "/opt/homebrew/opt/nvm/nvm.sh" ] && \. "/opt/homebrew/opt/nvm/nvm.sh"' >> "$HOME/.zshrc"
  # shellcheck disable=SC1090
  source "/opt/homebrew/opt/nvm/nvm.sh"
fi
nvm install "$NODE_VERSION" --default 2>/dev/null || true
ok "Node $(node --version 2>/dev/null || echo 'check shell restart')"

# ─── 7. Pull Ollama models ────────────────────────────────────────────────────
step "Pulling Ollama models"
warn "This will download ~35GB. Ensure adequate disk space or symlink to external NVMe first."
warn "To use external NVMe: ln -s /Volumes/YourDrive/ollama $HOME/.ollama/models"
echo ""

MODELS=(
  "deepseek-r1:32b-qwen-distill-q4_K_M"   # Research Agent (~19GB)
  "qwen3:14b"                               # Research Fast + Work-Life Agent (~9GB)
  "qwen3:8b"                               # Personal Agent (~5GB)
  "nomic-embed-text"                        # Embeddings for ChromaDB (~270MB)
)

for model in "${MODELS[@]}"; do
  echo -n "  Pulling $model … "
  ollama pull "$model" 2>&1 | tail -1
  ok "$model ready"
done

# ─── 8. Create OpenClaw directory structure ────────────────────────────────────
step "Creating OpenClaw directory structure"
mkdir -p "$LOG_DIR" "$MEMORY_DIR" "$VECTORDB_DIR/chroma" "$VECTORDB_DIR/mem0"
ok "Directories created at $OPENCLAW_DIR"

# ─── 9. OpenClaw agent orchestrator launchd ────────────────────────────────────
step "Registering OpenClaw Personal Agent as always-on launchd service"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_PLIST="$HOME/Library/LaunchAgents/com.openclaw.personal_agent.plist"

cat > "$AGENT_PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.openclaw.personal_agent</string>
  <key>ProgramArguments</key>
  <array>
    <string>$VENV_DIR/bin/python</string>
    <string>$SCRIPT_DIR/agent_orchestrator.py</string>
    <string>serve</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$LOG_DIR/personal_agent.log</string>
  <key>StandardErrorPath</key>
  <string>$LOG_DIR/personal_agent.err</string>
  <key>ThrottleInterval</key>
  <integer>30</integer>
</dict>
</plist>
EOF
ok "Personal Agent launchd plist written"

# ─── 10. Thermal & power management ──────────────────────────────────────────
step "Configuring macOS power management for sustained AI workload"
# Prevent sleep during inference
sudo pmset -a sleep 0
sudo pmset -a disksleep 0
sudo pmset -a proximitywake 0
sudo pmset -a powernap 0
# Keep display off but system awake
sudo pmset -a displaysleep 10
ok "Power management configured (no system sleep)"

# ─── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}════════════════════════════════════════════${NC}"
echo -e "${GREEN}  OpenClaw Setup Complete!${NC}"
echo -e "${GREEN}════════════════════════════════════════════${NC}"
echo ""
echo "  Ollama:   http://127.0.0.1:11434 (launchd, always-on)"
echo "  Python:   $VENV_DIR/bin/python"
echo "  Config:   $(find "$(cd "$SCRIPT_DIR/.." && pwd)" -name "openclaw.json" 2>/dev/null | head -1)"
echo "  Logs:     $LOG_DIR"
echo ""
echo "  Quick test:"
echo "    source $VENV_DIR/bin/activate"
echo "    python $SCRIPT_DIR/agent_orchestrator.py query --agent personal_agent --query 'Hello'"
echo ""
warn "Restart your terminal or run 'source ~/.zshrc' to apply PATH changes."
