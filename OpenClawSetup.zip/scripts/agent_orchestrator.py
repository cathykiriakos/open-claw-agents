"""
OpenClaw Agent Orchestrator
----------------------------
Loads openclaw.json and manages the three-agent team on a local Ollama backend.
Each agent is a configurable, reusable pattern — swap models by editing the JSON.

Usage:
    python agent_orchestrator.py --agent research --query "Summarize recent MoE papers"
    python agent_orchestrator.py --agent personal --query "What's on my calendar today?"
    python agent_orchestrator.py --agent worklife --query "Generate a dbt model for user_events"
    python agent_orchestrator.py --serve       # Run all agents as persistent HTTP endpoints

Requirements:
    pip install ollama chromadb mem0ai httpx pydantic schedule rich typer
"""

import json
import logging
import os
import sys
from pathlib import Path
from typing import Optional

import typer
import ollama
import chromadb
from chromadb.utils.embedding_functions import OllamaEmbeddingFunction
from pydantic import BaseModel
from rich.console import Console
from rich.logging import RichHandler
from rich.panel import Panel

# ─── Config ───────────────────────────────────────────────────────────────────

def _find_config() -> Path:
    """
    Search for openclaw.json in multiple locations so the script works
    regardless of whether a config/ subfolder exists.
    Priority order:
      1. config/openclaw.json  (relative to script's parent)
      2. openclaw.json         (flat — in same folder as script, or parent)
      3. OPENCLAW_CONFIG env var override
    """
    if "OPENCLAW_CONFIG" in os.environ:
        p = Path(os.environ["OPENCLAW_CONFIG"])
        if p.exists():
            return p

    script_dir = Path(__file__).parent
    candidates = [
        script_dir.parent / "config" / "openclaw.json",  # Open Claw/config/
        script_dir.parent / "openclaw.json",              # Open Claw/
        script_dir / "openclaw.json",                     # Open Claw/scripts/
        Path.home() / ".openclaw" / "openclaw.json",      # ~/.openclaw/
    ]
    for p in candidates:
        if p.exists():
            return p

    checked = "\n  ".join(str(c) for c in candidates)
    raise FileNotFoundError(
        f"openclaw.json not found. Checked:\n  {checked}\n"
        f"Set OPENCLAW_CONFIG=/full/path/to/openclaw.json to override."
    )

CONFIG_PATH = _find_config()

def load_config(path: Path = CONFIG_PATH) -> dict:
    """Load and resolve ~ paths in openclaw.json."""
    with open(path) as f:
        raw = json.load(f)
    # Expand ~ in all string values recursively
    return _expand_paths(raw)

def _expand_paths(obj):
    if isinstance(obj, dict):
        return {k: _expand_paths(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_paths(i) for i in obj]
    if isinstance(obj, str) and obj.startswith("~"):
        return str(Path(obj).expanduser())
    return obj

CONFIG = load_config()
RUNTIME = CONFIG["runtime"]
AGENTS = CONFIG["agents"]
VDB_CONFIG = CONFIG["vector_database"]
MEMORY_CONFIG = CONFIG["memory_layer"]

# ─── Logging ──────────────────────────────────────────────────────────────────

log_dir = Path(RUNTIME["log_dir"])
log_dir.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=getattr(logging, RUNTIME["log_level"]),
    format="%(message)s",
    handlers=[
        RichHandler(rich_tracebacks=True),
        logging.FileHandler(log_dir / "orchestrator.log"),
    ],
)
log = logging.getLogger("openclaw")
console = Console()

# ─── Vector DB Client ─────────────────────────────────────────────────────────

def get_chroma_client() -> chromadb.ClientAPI:
    """Return a persistent Chroma client."""
    persist_dir = VDB_CONFIG["persist_directory"]
    Path(persist_dir).mkdir(parents=True, exist_ok=True)
    return chromadb.PersistentClient(path=persist_dir)

def get_collection(client: chromadb.ClientAPI, collection_name: str):
    """Get or create a Chroma collection with Ollama embeddings."""
    embed_fn = OllamaEmbeddingFunction(
        url=f"{RUNTIME['ollama_host']}/api/embeddings",
        model_name=VDB_CONFIG["embedding_model"],
    )
    col_meta = VDB_CONFIG["collections"].get(collection_name, {})
    return client.get_or_create_collection(
        name=collection_name,
        embedding_function=embed_fn,
        metadata={"hnsw:space": col_meta.get("hnsw_space", "cosine")},
    )

# ─── Memory Layer (Mem0) ──────────────────────────────────────────────────────

def get_mem0_client():
    """Initialize Mem0 with local Ollama + Chroma backend."""
    try:
        from mem0 import Memory
    except ImportError:
        log.warning("mem0ai not installed. Run: pip install mem0ai")
        return None

    mem0_cfg = MEMORY_CONFIG["config"]
    config = {
        "llm": {
            "provider": mem0_cfg["llm_provider"],
            "config": {
                "model": mem0_cfg["llm_model"],
                "ollama_base_url": RUNTIME["ollama_host"],
            },
        },
        "embedder": {
            "provider": mem0_cfg["embedder_provider"],
            "config": {
                "model": mem0_cfg["embedder_model"],
                "ollama_base_url": RUNTIME["ollama_host"],
            },
        },
        "vector_store": {
            "provider": "chroma",
            "config": {
                "collection_name": "mem0_store",
                "path": mem0_cfg["vector_store_path"],
            },
        },
    }
    return Memory.from_config(config)

# ─── Agent Class ──────────────────────────────────────────────────────────────

class OpenClawAgent:
    """
    A configurable agent that wraps an Ollama model with:
    - System prompt from openclaw.json
    - Chroma vector memory (RAG)
    - Mem0 episodic memory
    - Conversation history
    """

    def __init__(self, agent_id: str):
        if agent_id not in AGENTS:
            raise ValueError(f"Unknown agent '{agent_id}'. Available: {list(AGENTS.keys())}")

        self.cfg = AGENTS[agent_id]
        self.id = agent_id
        self.name = self.cfg["name"]
        self.model = self.cfg["model"]
        self.system_prompt = self.cfg["system_prompt"]
        self.temperature = self.cfg.get("temperature", 0.3)
        self.max_tokens = self.cfg.get("max_tokens", 4096)
        self.collection_name = self.cfg["memory_collection"]

        self.chroma_client = get_chroma_client()
        self.collection = get_collection(self.chroma_client, self.collection_name)
        self.mem0 = get_mem0_client()

        self.history: list[dict] = []
        log.info(f"[{self.name}] Initialized with model={self.model}")

    def _retrieve_context(self, query: str, n_results: int = 5) -> str:
        """RAG: pull relevant chunks from Chroma."""
        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=n_results,
                include=["documents", "metadatas"],
            )
            docs = results.get("documents", [[]])[0]
            if not docs:
                return ""
            context_block = "\n\n---\n\n".join(docs)
            return f"<context>\n{context_block}\n</context>\n\n"
        except Exception as e:
            log.warning(f"[{self.name}] Chroma retrieval failed: {e}")
            return ""

    def _retrieve_mem0(self, query: str, user_id: str = "cathy") -> str:
        """Episodic memory from Mem0."""
        if not self.mem0:
            return ""
        try:
            raw = self.mem0.search(query, user_id=user_id)

            # mem0ai >= 0.1.x returns {"results": [...]}
            # mem0ai < 0.1.x returns a plain list
            if isinstance(raw, dict):
                results = raw.get("results", [])
            elif isinstance(raw, list):
                results = raw
            else:
                results = []

            if not results:
                return ""

            memories = "\n".join(f"- {r['memory']}" for r in results[:5])
            return f"<episodic_memory>\n{memories}\n</episodic_memory>\n\n"
        except Exception as e:
            log.warning(f"[{self.name}] Mem0 retrieval failed: {e}")
            return ""

    def ingest(self, text: str, metadata: Optional[dict] = None, doc_id: Optional[str] = None):
        """Add a document to this agent's Chroma collection."""
        import hashlib
        if doc_id is None:
            doc_id = hashlib.md5(text.encode()).hexdigest()
        self.collection.upsert(
            documents=[text],
            ids=[doc_id],
            metadatas=[metadata or {}],
        )
        log.info(f"[{self.name}] Ingested doc {doc_id[:8]}… ({len(text)} chars)")

    def chat(self, user_message: str, user_id: str = "cathy") -> str:
        """
        Main entry point: retrieves context, builds prompt, calls Ollama, stores memory.
        """
        # 1. Retrieve relevant context
        rag_context = self._retrieve_context(user_message)
        mem_context = self._retrieve_mem0(user_message, user_id)
        enriched_prompt = f"{rag_context}{mem_context}{user_message}"

        # 2. Build message list
        messages = [{"role": "system", "content": self.system_prompt}]
        messages.extend(self.history[-10:])  # Rolling window of last 10 turns
        messages.append({"role": "user", "content": enriched_prompt})

        # 3. Call Ollama
        log.info(f"[{self.name}] Calling {self.model}…")
        response = ollama.chat(
            model=self.model,
            messages=messages,
            options={
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
                "top_p": self.cfg.get("top_p", 0.9),
            },
        )
        assistant_reply = response["message"]["content"]

        # 4. Update history
        self.history.append({"role": "user", "content": user_message})
        self.history.append({"role": "assistant", "content": assistant_reply})

        # 5. Store in Mem0 (async pattern — don't block on this)
        if self.mem0:
            try:
                self.mem0.add(
                    [{"role": "user", "content": user_message},
                     {"role": "assistant", "content": assistant_reply}],
                    user_id=user_id,
                    agent_id=self.id,
                )
            except TypeError:
                # Older mem0ai versions don't accept agent_id — fall back
                self.mem0.add(
                    [{"role": "user", "content": user_message},
                     {"role": "assistant", "content": assistant_reply}],
                    user_id=user_id,
                )
            except Exception as e:
                log.warning(f"[{self.name}] Mem0 store failed: {e}")

        return assistant_reply

    def reset_history(self):
        """Clear conversation history (not memory)."""
        self.history = []
        log.info(f"[{self.name}] Conversation history cleared.")

# ─── CLI ──────────────────────────────────────────────────────────────────────

app = typer.Typer(help="OpenClaw Agent Orchestrator")

AGENT_CHOICES = ["research_agent", "personal_agent", "worklife_agent"]


@app.command()
def query(
    agent: str = typer.Option(..., "--agent", "-a", help=f"Agent ID: {AGENT_CHOICES}"),
    prompt: str = typer.Option(..., "--query", "-q", help="Query to send to the agent"),
    user_id: str = typer.Option("cathy", "--user", help="User ID for memory scoping"),
):
    """Send a one-shot query to a specific agent."""
    oc_agent = OpenClawAgent(agent)
    console.print(Panel(f"[bold cyan]{oc_agent.name}[/bold cyan] | model: {oc_agent.model}"))
    reply = oc_agent.chat(prompt, user_id=user_id)
    console.print(Panel(reply, title="Response", border_style="green"))


@app.command()
def interactive(
    agent: str = typer.Option(..., "--agent", "-a", help=f"Agent ID: {AGENT_CHOICES}"),
    user_id: str = typer.Option("cathy", "--user", help="User ID for memory scoping"),
):
    """Start an interactive REPL session with an agent."""
    oc_agent = OpenClawAgent(agent)
    console.print(Panel(
        f"[bold]{oc_agent.name}[/bold]  |  model=[cyan]{oc_agent.model}[/cyan]\n"
        f"Type 'exit' to quit, 'reset' to clear history.",
        title="OpenClaw REPL"
    ))
    while True:
        try:
            user_input = input("\n[You] ").strip()
            if user_input.lower() in ("exit", "quit"):
                break
            if user_input.lower() == "reset":
                oc_agent.reset_history()
                console.print("[yellow]History cleared.[/yellow]")
                continue
            if not user_input:
                continue
            reply = oc_agent.chat(user_input, user_id=user_id)
            console.print(f"\n[{oc_agent.name}] {reply}")
        except KeyboardInterrupt:
            break
    console.print("[dim]Session ended.[/dim]")


@app.command()
def ingest(
    agent: str = typer.Option(..., "--agent", "-a"),
    file_path: str = typer.Option(..., "--file", "-f", help="Path to .txt or .md file"),
    doc_id: Optional[str] = typer.Option(None, "--id", help="Optional document ID"),
    tag: Optional[str] = typer.Option(None, "--tag", help="Metadata tag"),
):
    """Ingest a document into an agent's vector memory."""
    path = Path(file_path).expanduser()
    if not path.exists():
        console.print(f"[red]File not found: {path}[/red]")
        raise typer.Exit(1)

    text = path.read_text(encoding="utf-8")
    metadata = {"source": str(path), "tag": tag or "manual"}

    oc_agent = OpenClawAgent(agent)
    oc_agent.ingest(text, metadata=metadata, doc_id=doc_id)
    console.print(f"[green]✓ Ingested {path.name} → {oc_agent.collection_name}[/green]")


@app.command()
def serve():
    """
    Placeholder: launch all agents as persistent background processes.
    In production, wrap each agent in a FastAPI endpoint.
    """
    console.print("[yellow]serve mode: launch agents as FastAPI endpoints (see docs)[/yellow]")
    for agent_id in AGENT_CHOICES:
        console.print(f"  → Would start {agent_id} on port {8100 + AGENT_CHOICES.index(agent_id)}")


if __name__ == "__main__":
    app()
